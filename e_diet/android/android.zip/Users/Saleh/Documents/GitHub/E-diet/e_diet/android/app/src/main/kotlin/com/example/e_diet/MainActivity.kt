package com.example.e_diet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
